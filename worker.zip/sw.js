// ABIBI Worker PWA Service Worker
self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
// fetch 핸들러 (설치 조건 충족 - 항상 네트워크 우선)
self.addEventListener('fetch', e => {
  e.respondWith(fetch(e.request).catch(() => new Response('오프라인', { status: 503 })));
});
