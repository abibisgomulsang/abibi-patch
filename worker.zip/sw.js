// ABIBI Worker PWA Service Worker (안전 버전 - 네트워크 통과만)
self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => {
  // 기존 캐시 모두 삭제 (흰 화면 방지)
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k)))).then(() => self.clients.claim())
  );
});
// fetch 가로채지 않음 - 항상 네트워크 그대로 (흰 화면 방지)
